# Risk Mitigation (Draft)
- Re-identification risk: k-anonymity, spatial resolution limits, aggregation.
- Security: encrypted drives/folders, role-based access.
- Publication ethics: harm minimization; blur/aggregate maps where necessary.
