# Positionality Statement (Draft)
- Researcher standpoint; awareness of potential biases and limits of data contact.
- Conflict of interest declaration: …
- Transparency: decision logs, model assumptions, change tracking.
