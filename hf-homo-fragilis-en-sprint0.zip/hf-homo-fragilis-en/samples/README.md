This folder contains **pilot data** templates you can version before wiring DVC.
Add your small CSV/GeoJSON samples here during Sprint‑0.
